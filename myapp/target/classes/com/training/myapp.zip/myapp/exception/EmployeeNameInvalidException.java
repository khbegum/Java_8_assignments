package com.training.myapp.exception;

public class EmployeeNameInvalidException extends Exception {
public EmployeeNameInvalidException(String message) {
super(message);	
}
}
