package com.training.myapp.exception;

public class AgeNotWithInRangeException extends Exception {

	public AgeNotWithInRangeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
