package com.training.myapp.exception;

public class InvalidException extends Exception {

	public InvalidException(String message) {
		super(message);
		
		// TODO Auto-generated constructor stub
	}

}
