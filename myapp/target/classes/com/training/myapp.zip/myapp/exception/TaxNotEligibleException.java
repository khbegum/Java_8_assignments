package com.training.myapp.exception;

public class TaxNotEligibleException extends Exception {
public TaxNotEligibleException(String message) {
	super(message);
}
}
