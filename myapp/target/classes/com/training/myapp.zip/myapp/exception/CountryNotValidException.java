package com.training.myapp.exception;

public class CountryNotValidException extends Exception {
public CountryNotValidException(String message) {
	super(message);
}
}
