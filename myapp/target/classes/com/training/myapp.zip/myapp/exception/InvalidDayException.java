package com.training.myapp.exception;

public class InvalidDayException extends Exception {

	public InvalidDayException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
