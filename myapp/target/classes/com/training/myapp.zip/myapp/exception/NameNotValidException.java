package com.training.myapp.exception;

public class NameNotValidException extends Exception {

	public NameNotValidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
