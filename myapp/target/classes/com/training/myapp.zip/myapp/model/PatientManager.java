package com.training.myapp.model;

import java.util.Scanner;

public class PatientManager {
private Patient waitingList;
public void start() {
	System.out.println("(1) New Patient"+"\n"+"(2) Next Patient"+"\n"+"(3) Waiting List"+"\n"+"(4)Exit");
	
}
	
	
}
