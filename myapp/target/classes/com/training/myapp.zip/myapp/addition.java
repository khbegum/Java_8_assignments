package com.training.myapp;

public class addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static int add(int number1, int number2) {
		// TODO Auto-generated method stub
		return number1+number2;
	}

}
