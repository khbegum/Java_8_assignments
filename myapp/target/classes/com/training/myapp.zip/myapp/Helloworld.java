package com.training.myapp;

public class Helloworld {

	public static String greet(String greet) {
	System.out.println(greet);
		// TODO Auto-generated method stub
		return greet;
	}

}
